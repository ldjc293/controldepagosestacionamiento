-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: estacionamiento_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apartamento_usuario`
--

DROP TABLE IF EXISTS `apartamento_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamento_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `cantidad_controles` int(11) DEFAULT 0 COMMENT 'Número de controles asignados',
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `activo` tinyint(1) DEFAULT 1 COMMENT 'FALSE cuando se muda o transfiere',
  PRIMARY KEY (`id`),
  KEY `idx_apartamento` (`apartamento_id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `apartamento_usuario_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `apartamento_usuario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Relación apartamentos-usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamento_usuario`
--

LOCK TABLES `apartamento_usuario` WRITE;
/*!40000 ALTER TABLE `apartamento_usuario` DISABLE KEYS */;
INSERT INTO `apartamento_usuario` VALUES (1,61,4,2,'2025-11-24 23:32:07',1),(2,73,5,1,'2025-11-24 23:32:07',1),(3,85,6,2,'2025-11-24 23:32:07',1),(4,9,7,2,'2025-11-24 23:32:07',1),(5,10,8,3,'2025-11-24 23:32:07',1),(6,25,9,1,'2025-11-24 23:32:07',1),(7,49,10,2,'2025-11-24 23:32:07',1);
/*!40000 ALTER TABLE `apartamento_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartamentos`
--

DROP TABLE IF EXISTS `apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloque` varchar(10) NOT NULL COMMENT 'Bloques: 27, 28, 29, 30, 31, 32',
  `escalera` varchar(5) NOT NULL COMMENT 'Escaleras: A, B, C',
  `piso` int(11) NOT NULL COMMENT 'Piso del apartamento',
  `numero_apartamento` varchar(10) NOT NULL COMMENT 'Número del apto (Ej: 501, 502)',
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_apartamento` (`bloque`,`escalera`,`piso`,`numero_apartamento`),
  KEY `idx_bloque` (`bloque`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Apartamentos de los bloques 27-32';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamentos`
--

LOCK TABLES `apartamentos` WRITE;
/*!40000 ALTER TABLE `apartamentos` DISABLE KEYS */;
INSERT INTO `apartamentos` VALUES (1,'27','1',1,'101',1,'2025-11-24 23:32:06'),(2,'27','1',1,'102',1,'2025-11-24 23:32:06'),(3,'27','1',2,'201',1,'2025-11-24 23:32:06'),(4,'27','1',2,'202',1,'2025-11-24 23:32:06'),(5,'27','1',3,'301',1,'2025-11-24 23:32:06'),(6,'27','1',3,'302',1,'2025-11-24 23:32:06'),(7,'27','1',4,'401',1,'2025-11-24 23:32:06'),(8,'27','1',4,'402',1,'2025-11-24 23:32:06'),(9,'27','1',5,'501',1,'2025-11-24 23:32:06'),(10,'27','1',5,'502',1,'2025-11-24 23:32:06'),(11,'27','1',6,'601',1,'2025-11-24 23:32:06'),(12,'27','1',6,'602',1,'2025-11-24 23:32:06'),(13,'27','2',1,'101',1,'2025-11-24 23:32:06'),(14,'27','2',1,'102',1,'2025-11-24 23:32:06'),(15,'27','2',2,'201',1,'2025-11-24 23:32:06'),(16,'27','2',2,'202',1,'2025-11-24 23:32:06'),(17,'27','2',3,'301',1,'2025-11-24 23:32:06'),(18,'27','2',3,'302',1,'2025-11-24 23:32:06'),(19,'27','2',4,'401',1,'2025-11-24 23:32:06'),(20,'27','2',4,'402',1,'2025-11-24 23:32:06'),(21,'27','2',5,'501',1,'2025-11-24 23:32:06'),(22,'27','2',5,'502',1,'2025-11-24 23:32:06'),(23,'27','2',6,'601',1,'2025-11-24 23:32:06'),(24,'27','2',6,'602',1,'2025-11-24 23:32:06'),(25,'27','3',1,'101',1,'2025-11-24 23:32:06'),(26,'27','3',1,'102',1,'2025-11-24 23:32:06'),(27,'27','3',2,'201',1,'2025-11-24 23:32:06'),(28,'27','3',2,'202',1,'2025-11-24 23:32:06'),(29,'27','3',3,'301',1,'2025-11-24 23:32:06'),(30,'27','3',3,'302',1,'2025-11-24 23:32:06'),(31,'27','3',4,'401',1,'2025-11-24 23:32:06'),(32,'27','3',4,'402',1,'2025-11-24 23:32:06'),(33,'27','3',5,'501',1,'2025-11-24 23:32:06'),(34,'27','3',5,'502',1,'2025-11-24 23:32:06'),(35,'27','3',6,'601',1,'2025-11-24 23:32:06'),(36,'27','3',6,'602',1,'2025-11-24 23:32:06'),(37,'27','4',1,'101',1,'2025-11-24 23:32:06'),(38,'27','4',1,'102',1,'2025-11-24 23:32:06'),(39,'27','4',2,'201',1,'2025-11-24 23:32:06'),(40,'27','4',2,'202',1,'2025-11-24 23:32:06'),(41,'27','4',3,'301',1,'2025-11-24 23:32:06'),(42,'27','4',3,'302',1,'2025-11-24 23:32:06'),(43,'27','4',4,'401',1,'2025-11-24 23:32:06'),(44,'27','4',4,'402',1,'2025-11-24 23:32:06'),(45,'27','4',5,'501',1,'2025-11-24 23:32:06'),(46,'27','4',5,'502',1,'2025-11-24 23:32:06'),(47,'27','4',6,'601',1,'2025-11-24 23:32:06'),(48,'27','4',6,'602',1,'2025-11-24 23:32:06'),(49,'28','1',1,'101',1,'2025-11-24 23:32:06'),(50,'28','1',1,'102',1,'2025-11-24 23:32:06'),(51,'28','1',2,'201',1,'2025-11-24 23:32:06'),(52,'28','1',2,'202',1,'2025-11-24 23:32:06'),(53,'28','1',3,'301',1,'2025-11-24 23:32:06'),(54,'28','1',3,'302',1,'2025-11-24 23:32:06'),(55,'28','1',4,'401',1,'2025-11-24 23:32:06'),(56,'28','1',4,'402',1,'2025-11-24 23:32:06'),(57,'28','1',5,'501',1,'2025-11-24 23:32:06'),(58,'28','1',5,'502',1,'2025-11-24 23:32:06'),(59,'28','1',6,'601',1,'2025-11-24 23:32:06'),(60,'28','1',6,'602',1,'2025-11-24 23:32:06'),(61,'29','1',1,'101',1,'2025-11-24 23:32:06'),(62,'29','1',1,'102',1,'2025-11-24 23:32:06'),(63,'29','1',2,'201',1,'2025-11-24 23:32:06'),(64,'29','1',2,'202',1,'2025-11-24 23:32:06'),(65,'29','1',3,'301',1,'2025-11-24 23:32:06'),(66,'29','1',3,'302',1,'2025-11-24 23:32:06'),(67,'29','1',4,'401',1,'2025-11-24 23:32:06'),(68,'29','1',4,'402',1,'2025-11-24 23:32:06'),(69,'29','1',5,'501',1,'2025-11-24 23:32:06'),(70,'29','1',5,'502',1,'2025-11-24 23:32:06'),(71,'29','1',6,'601',1,'2025-11-24 23:32:06'),(72,'29','1',6,'602',1,'2025-11-24 23:32:06'),(73,'29','2',1,'101',1,'2025-11-24 23:32:06'),(74,'29','2',1,'102',1,'2025-11-24 23:32:06'),(75,'29','2',2,'201',1,'2025-11-24 23:32:06'),(76,'29','2',2,'202',1,'2025-11-24 23:32:06'),(77,'29','2',3,'301',1,'2025-11-24 23:32:06'),(78,'29','2',3,'302',1,'2025-11-24 23:32:06'),(79,'29','2',4,'401',1,'2025-11-24 23:32:06'),(80,'29','2',4,'402',1,'2025-11-24 23:32:06'),(81,'29','2',5,'501',1,'2025-11-24 23:32:06'),(82,'29','2',5,'502',1,'2025-11-24 23:32:06'),(83,'29','2',6,'601',1,'2025-11-24 23:32:06'),(84,'29','2',6,'602',1,'2025-11-24 23:32:06'),(85,'30','1',1,'101',1,'2025-11-24 23:32:06'),(86,'30','1',1,'102',1,'2025-11-24 23:32:06'),(87,'30','1',2,'201',1,'2025-11-24 23:32:06'),(88,'30','1',2,'202',1,'2025-11-24 23:32:06'),(89,'30','1',3,'301',1,'2025-11-24 23:32:06'),(90,'30','1',3,'302',1,'2025-11-24 23:32:06'),(91,'30','1',4,'401',1,'2025-11-24 23:32:06'),(92,'30','1',4,'402',1,'2025-11-24 23:32:06'),(93,'30','1',5,'501',1,'2025-11-24 23:32:06'),(94,'30','1',5,'502',1,'2025-11-24 23:32:06'),(95,'30','1',6,'601',1,'2025-11-24 23:32:06'),(96,'30','1',6,'602',1,'2025-11-24 23:32:06'),(97,'31','1',1,'101',1,'2025-11-24 23:32:06'),(98,'31','1',1,'102',1,'2025-11-24 23:32:06'),(99,'31','1',2,'201',1,'2025-11-24 23:32:06'),(100,'31','1',2,'202',1,'2025-11-24 23:32:06'),(101,'31','1',3,'301',1,'2025-11-24 23:32:06'),(102,'31','1',3,'302',1,'2025-11-24 23:32:06'),(103,'31','1',4,'401',1,'2025-11-24 23:32:06'),(104,'31','1',4,'402',1,'2025-11-24 23:32:06'),(105,'31','1',5,'501',1,'2025-11-24 23:32:06'),(106,'31','1',5,'502',1,'2025-11-24 23:32:06'),(107,'31','1',6,'601',1,'2025-11-24 23:32:06'),(108,'31','1',6,'602',1,'2025-11-24 23:32:06'),(109,'32','1',1,'101',1,'2025-11-24 23:32:06'),(110,'32','1',1,'102',1,'2025-11-24 23:32:06'),(111,'32','1',2,'201',1,'2025-11-24 23:32:06'),(112,'32','1',2,'202',1,'2025-11-24 23:32:06'),(113,'32','1',3,'301',1,'2025-11-24 23:32:06'),(114,'32','1',3,'302',1,'2025-11-24 23:32:06'),(115,'32','1',4,'401',1,'2025-11-24 23:32:06'),(116,'32','1',4,'402',1,'2025-11-24 23:32:06'),(117,'32','1',5,'501',1,'2025-11-24 23:32:06'),(118,'32','1',5,'502',1,'2025-11-24 23:32:06'),(119,'32','1',6,'601',1,'2025-11-24 23:32:06'),(120,'32','1',6,'602',1,'2025-11-24 23:32:06'),(121,'32','2',1,'101',1,'2025-11-24 23:32:06'),(122,'32','2',1,'102',1,'2025-11-24 23:32:06'),(123,'32','2',2,'201',1,'2025-11-24 23:32:06'),(124,'32','2',2,'202',1,'2025-11-24 23:32:06'),(125,'32','2',3,'301',1,'2025-11-24 23:32:06'),(126,'32','2',3,'302',1,'2025-11-24 23:32:06'),(127,'32','2',4,'401',1,'2025-11-24 23:32:06'),(128,'32','2',4,'402',1,'2025-11-24 23:32:06'),(129,'32','2',5,'501',1,'2025-11-24 23:32:06'),(130,'32','2',5,'502',1,'2025-11-24 23:32:06'),(131,'32','2',6,'601',1,'2025-11-24 23:32:06'),(132,'32','2',6,'602',1,'2025-11-24 23:32:06'),(133,'32','3',1,'101',1,'2025-11-24 23:32:06'),(134,'32','3',1,'102',1,'2025-11-24 23:32:06'),(135,'32','3',2,'201',1,'2025-11-24 23:32:06'),(136,'32','3',2,'202',1,'2025-11-24 23:32:06'),(137,'32','3',3,'301',1,'2025-11-24 23:32:06'),(138,'32','3',3,'302',1,'2025-11-24 23:32:06'),(139,'32','3',4,'401',1,'2025-11-24 23:32:06'),(140,'32','3',4,'402',1,'2025-11-24 23:32:06'),(141,'32','3',5,'501',1,'2025-11-24 23:32:06'),(142,'32','3',5,'502',1,'2025-11-24 23:32:06'),(143,'32','3',6,'601',1,'2025-11-24 23:32:06'),(144,'32','3',6,'602',1,'2025-11-24 23:32:06');
/*!40000 ALTER TABLE `apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_cron`
--

DROP TABLE IF EXISTS `configuracion_cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tarea` varchar(100) NOT NULL COMMENT 'Nombre único de la tarea (ej: generar_mensualidades)',
  `descripcion` text DEFAULT NULL,
  `script_path` varchar(255) NOT NULL COMMENT 'Ruta relativa al script PHP',
  `activo` tinyint(1) DEFAULT 1,
  `frecuencia` varchar(100) NOT NULL COMMENT 'Ej: "Diario", "Mensual"',
  `hora_ejecucion` time DEFAULT NULL COMMENT 'Hora preferida de ejecución (HH:MM:SS)',
  `dia_mes` int(11) DEFAULT NULL COMMENT 'Día del mes para tareas mensuales (1-31)',
  `ultima_ejecucion` datetime DEFAULT NULL,
  `ultimo_resultado` enum('exitoso','fallido','pendiente') DEFAULT 'pendiente',
  `ultimo_mensaje` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_tarea` (`nombre_tarea`),
  KEY `idx_nombre_tarea` (`nombre_tarea`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Configuración y estado de tareas CRON';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_cron`
--

LOCK TABLES `configuracion_cron` WRITE;
/*!40000 ALTER TABLE `configuracion_cron` DISABLE KEYS */;
INSERT INTO `configuracion_cron` VALUES (1,'generar_mensualidades','Genera las mensualidades para todos los clientes activos el dÝa 5 de cada mes.','cron/generar_mensualidades.php',1,'Mensual','00:05:00',5,'2025-11-25 07:19:17','pendiente',NULL),(2,'verificar_bloqueos','Verifica clientes con 4+ meses de mora y bloquea sus controles.','cron/verificar_bloqueos.php',1,'Diario','01:00:00',NULL,NULL,'pendiente',NULL),(3,'enviar_notificaciones','EnvÝa notificaciones pendientes por email (alertas de mora, etc.).','cron/enviar_notificaciones.php',1,'Diario','09:00:00',NULL,NULL,'pendiente',NULL),(4,'actualizar_tasa_bcv','Intenta actualizar la tasa de cambio desde el BCV automßticamente.','cron/actualizar_tasa_bcv.php',1,'Diario','10:00:00',NULL,'2025-11-24 22:50:42','pendiente',NULL),(5,'backup_database','Realiza un backup completo de la base de datos.','cron/backup_database.php',1,'Diario','02:00:00',NULL,NULL,'pendiente',NULL);
/*!40000 ALTER TABLE `configuracion_cron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_tarifas`
--

DROP TABLE IF EXISTS `configuracion_tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_tarifas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto_mensual_usd` decimal(10,2) NOT NULL DEFAULT 1.00 COMMENT 'Tarifa en USD por control',
  `meses_bloqueo` int(11) NOT NULL DEFAULT 2 COMMENT 'Meses de mora para bloqueo automático de controles',
  `fecha_vigencia_inicio` date NOT NULL,
  `fecha_vigencia_fin` date DEFAULT NULL COMMENT 'NULL = vigencia actual',
  `activo` tinyint(1) DEFAULT 1,
  `creado_por` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_vigencia` (`fecha_vigencia_inicio`,`fecha_vigencia_fin`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `configuracion_tarifas_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tarifas mensuales configurables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_tarifas`
--

LOCK TABLES `configuracion_tarifas` WRITE;
/*!40000 ALTER TABLE `configuracion_tarifas` DISABLE KEYS */;
INSERT INTO `configuracion_tarifas` VALUES (1,2.00,2,'2025-11-15',NULL,0,NULL,'2025-11-16 02:48:09'),(2,1.00,2,'2025-11-24',NULL,0,1,'2025-11-25 02:50:54'),(3,1.00,4,'2025-11-24',NULL,0,1,'2025-11-25 02:50:59'),(4,1.00,4,'2025-11-25',NULL,1,1,'2025-11-25 11:41:12');
/*!40000 ALTER TABLE `configuracion_tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controles_estacionamiento`
--

DROP TABLE IF EXISTS `controles_estacionamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `controles_estacionamiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) DEFAULT NULL COMMENT 'NULL = control vacío/sin asignar',
  `posicion_numero` int(11) NOT NULL COMMENT 'Posición física: 1-250',
  `receptor` enum('A','B') NOT NULL COMMENT 'Receptor A o B',
  `numero_control_completo` varchar(10) NOT NULL COMMENT 'Ej: 1A, 15B, 250A',
  `estado` enum('activo','suspendido','desactivado','perdido','bloqueado','vacio') DEFAULT 'vacio',
  `motivo_estado` text DEFAULT NULL COMMENT 'Motivo de suspensión, desactivación, etc.',
  `fecha_estado` timestamp NOT NULL DEFAULT current_timestamp(),
  `aprobado_por` int(11) DEFAULT NULL COMMENT 'Usuario que aprobó cambio de estado',
  `fecha_asignacion` datetime DEFAULT NULL COMMENT 'Fecha cuando se asignó a un usuario',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_control_completo` (`numero_control_completo`),
  UNIQUE KEY `unique_posicion_receptor` (`posicion_numero`,`receptor`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_estado` (`estado`),
  KEY `idx_posicion` (`posicion_numero`),
  KEY `idx_receptor` (`receptor`),
  KEY `idx_control_apartamento` (`apartamento_usuario_id`,`estado`),
  CONSTRAINT `controles_estacionamiento_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE SET NULL,
  CONSTRAINT `controles_estacionamiento_ibfk_2` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='500 controles totales (250×2 receptores)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controles_estacionamiento`
--

LOCK TABLES `controles_estacionamiento` WRITE;
/*!40000 ALTER TABLE `controles_estacionamiento` DISABLE KEYS */;
INSERT INTO `controles_estacionamiento` VALUES (1,NULL,1,'A','1A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(2,NULL,1,'B','1B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(3,NULL,2,'A','2A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(4,NULL,2,'B','2B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(5,NULL,3,'A','3A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(6,NULL,3,'B','3B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(7,NULL,4,'A','4A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(8,NULL,4,'B','4B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(9,NULL,5,'A','5A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(10,NULL,5,'B','5B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(11,NULL,6,'A','6A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(12,NULL,6,'B','6B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(13,NULL,7,'A','7A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(14,NULL,7,'B','7B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(15,NULL,8,'A','8A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(16,NULL,8,'B','8B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(17,NULL,9,'A','9A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(18,NULL,9,'B','9B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(19,NULL,10,'A','10A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(20,NULL,10,'B','10B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(21,NULL,11,'A','11A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(22,NULL,11,'B','11B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(23,NULL,12,'A','12A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(24,NULL,12,'B','12B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(25,NULL,13,'A','13A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(26,NULL,13,'B','13B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(27,NULL,14,'A','14A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(28,NULL,14,'B','14B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(29,1,15,'A','15A','activo',NULL,'2025-11-24 23:32:06',NULL,'2025-11-24 19:32:07'),(30,1,15,'B','15B','activo',NULL,'2025-11-24 23:32:06',NULL,'2025-11-24 19:32:07'),(31,NULL,16,'A','16A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(32,NULL,16,'B','16B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(33,NULL,17,'A','17A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(34,NULL,17,'B','17B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(35,NULL,18,'A','18A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(36,NULL,18,'B','18B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(37,NULL,19,'A','19A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(38,NULL,19,'B','19B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(39,NULL,20,'A','20A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(40,NULL,20,'B','20B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(41,NULL,21,'A','21A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(42,NULL,21,'B','21B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(43,NULL,22,'A','22A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(44,NULL,22,'B','22B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(45,NULL,23,'A','23A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(46,NULL,23,'B','23B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(47,NULL,24,'A','24A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(48,NULL,24,'B','24B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(49,NULL,25,'A','25A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(50,NULL,25,'B','25B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(51,NULL,26,'A','26A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(52,NULL,26,'B','26B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(53,NULL,27,'A','27A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(54,NULL,27,'B','27B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(55,NULL,28,'A','28A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(56,NULL,28,'B','28B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(57,NULL,29,'A','29A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(58,NULL,29,'B','29B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(59,4,30,'A','30A','activo',NULL,'2025-11-24 23:32:06',NULL,'2025-11-24 19:32:07'),(60,4,30,'B','30B','activo',NULL,'2025-11-24 23:32:06',NULL,'2025-11-24 19:32:07'),(61,NULL,31,'A','31A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(62,NULL,31,'B','31B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(63,NULL,32,'A','32A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(64,NULL,32,'B','32B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(65,NULL,33,'A','33A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(66,NULL,33,'B','33B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(67,NULL,34,'A','34A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(68,NULL,34,'B','34B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(69,NULL,35,'A','35A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(70,NULL,35,'B','35B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(71,NULL,36,'A','36A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(72,NULL,36,'B','36B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(73,NULL,37,'A','37A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(74,NULL,37,'B','37B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(75,NULL,38,'A','38A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(76,NULL,38,'B','38B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(77,NULL,39,'A','39A','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(78,NULL,39,'B','39B','vacio',NULL,'2025-11-24 23:32:06',NULL,NULL),(79,NULL,40,'A','40A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(80,NULL,40,'B','40B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(81,NULL,41,'A','41A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(82,NULL,41,'B','41B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(83,NULL,42,'A','42A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(84,NULL,42,'B','42B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(85,NULL,43,'A','43A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(86,NULL,43,'B','43B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(87,NULL,44,'A','44A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(88,NULL,44,'B','44B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(89,3,45,'A','45A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(90,3,45,'B','45B','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(91,NULL,46,'A','46A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(92,NULL,46,'B','46B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(93,NULL,47,'A','47A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(94,NULL,47,'B','47B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(95,NULL,48,'A','48A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(96,NULL,48,'B','48B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(97,NULL,49,'A','49A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(98,NULL,49,'B','49B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(99,5,50,'A','50A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(100,5,50,'B','50B','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(101,5,51,'A','51A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(102,NULL,51,'B','51B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(103,NULL,52,'A','52A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(104,NULL,52,'B','52B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(105,NULL,53,'A','53A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(106,NULL,53,'B','53B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(107,NULL,54,'A','54A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(108,NULL,54,'B','54B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(109,NULL,55,'A','55A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(110,NULL,55,'B','55B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(111,NULL,56,'A','56A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(112,NULL,56,'B','56B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(113,NULL,57,'A','57A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(114,NULL,57,'B','57B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(115,NULL,58,'A','58A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(116,NULL,58,'B','58B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(117,NULL,59,'A','59A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(118,NULL,59,'B','59B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(119,6,60,'A','60A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(120,NULL,60,'B','60B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(121,NULL,61,'A','61A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(122,NULL,61,'B','61B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(123,NULL,62,'A','62A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(124,NULL,62,'B','62B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(125,NULL,63,'A','63A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(126,NULL,63,'B','63B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(127,NULL,64,'A','64A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(128,NULL,64,'B','64B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(129,NULL,65,'A','65A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(130,NULL,65,'B','65B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(131,NULL,66,'A','66A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(132,NULL,66,'B','66B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(133,NULL,67,'A','67A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(134,NULL,67,'B','67B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(135,NULL,68,'A','68A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(136,NULL,68,'B','68B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(137,NULL,69,'A','69A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(138,NULL,69,'B','69B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(139,NULL,70,'A','70A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(140,NULL,70,'B','70B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(141,NULL,71,'A','71A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(142,NULL,71,'B','71B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(143,NULL,72,'A','72A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(144,NULL,72,'B','72B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(145,NULL,73,'A','73A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(146,NULL,73,'B','73B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(147,NULL,74,'A','74A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(148,NULL,74,'B','74B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(149,7,75,'A','75A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(150,7,75,'B','75B','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(151,NULL,76,'A','76A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(152,NULL,76,'B','76B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(153,NULL,77,'A','77A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(154,NULL,77,'B','77B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(155,NULL,78,'A','78A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(156,NULL,78,'B','78B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(157,NULL,79,'A','79A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(158,NULL,79,'B','79B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(159,NULL,80,'A','80A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(160,NULL,80,'B','80B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(161,NULL,81,'A','81A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(162,NULL,81,'B','81B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(163,NULL,82,'A','82A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(164,NULL,82,'B','82B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(165,NULL,83,'A','83A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(166,NULL,83,'B','83B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(167,NULL,84,'A','84A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(168,NULL,84,'B','84B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(169,NULL,85,'A','85A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(170,NULL,85,'B','85B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(171,NULL,86,'A','86A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(172,NULL,86,'B','86B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(173,NULL,87,'A','87A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(174,NULL,87,'B','87B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(175,NULL,88,'A','88A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(176,NULL,88,'B','88B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(177,NULL,89,'A','89A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(178,NULL,89,'B','89B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(179,NULL,90,'A','90A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(180,NULL,90,'B','90B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(181,NULL,91,'A','91A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(182,NULL,91,'B','91B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(183,NULL,92,'A','92A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(184,NULL,92,'B','92B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(185,NULL,93,'A','93A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(186,NULL,93,'B','93B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(187,NULL,94,'A','94A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(188,NULL,94,'B','94B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(189,NULL,95,'A','95A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(190,NULL,95,'B','95B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(191,NULL,96,'A','96A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(192,NULL,96,'B','96B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(193,NULL,97,'A','97A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(194,NULL,97,'B','97B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(195,NULL,98,'A','98A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(196,NULL,98,'B','98B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(197,NULL,99,'A','99A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(198,NULL,99,'B','99B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(199,NULL,100,'A','100A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(200,NULL,100,'B','100B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(201,NULL,101,'A','101A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(202,NULL,101,'B','101B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(203,NULL,102,'A','102A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(204,NULL,102,'B','102B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(205,NULL,103,'A','103A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(206,NULL,103,'B','103B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(207,NULL,104,'A','104A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(208,NULL,104,'B','104B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(209,NULL,105,'A','105A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(210,NULL,105,'B','105B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(211,NULL,106,'A','106A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(212,NULL,106,'B','106B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(213,NULL,107,'A','107A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(214,NULL,107,'B','107B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(215,NULL,108,'A','108A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(216,NULL,108,'B','108B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(217,NULL,109,'A','109A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(218,NULL,109,'B','109B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(219,NULL,110,'A','110A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(220,NULL,110,'B','110B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(221,NULL,111,'A','111A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(222,NULL,111,'B','111B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(223,NULL,112,'A','112A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(224,NULL,112,'B','112B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(225,NULL,113,'A','113A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(226,NULL,113,'B','113B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(227,NULL,114,'A','114A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(228,NULL,114,'B','114B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(229,NULL,115,'A','115A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(230,NULL,115,'B','115B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(231,NULL,116,'A','116A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(232,NULL,116,'B','116B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(233,NULL,117,'A','117A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(234,NULL,117,'B','117B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(235,NULL,118,'A','118A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(236,NULL,118,'B','118B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(237,NULL,119,'A','119A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(238,NULL,119,'B','119B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(239,NULL,120,'A','120A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(240,NULL,120,'B','120B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(241,NULL,121,'A','121A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(242,NULL,121,'B','121B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(243,NULL,122,'A','122A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(244,NULL,122,'B','122B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(245,NULL,123,'A','123A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(246,NULL,123,'B','123B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(247,NULL,124,'A','124A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(248,NULL,124,'B','124B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(249,NULL,125,'A','125A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(250,NULL,125,'B','125B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(251,NULL,126,'A','126A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(252,NULL,126,'B','126B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(253,2,127,'A','127A','activo',NULL,'2025-11-24 23:32:07',NULL,'2025-11-24 19:32:07'),(254,NULL,127,'B','127B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(255,NULL,128,'A','128A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(256,NULL,128,'B','128B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(257,NULL,129,'A','129A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(258,NULL,129,'B','129B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(259,NULL,130,'A','130A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(260,NULL,130,'B','130B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(261,NULL,131,'A','131A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(262,NULL,131,'B','131B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(263,NULL,132,'A','132A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(264,NULL,132,'B','132B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(265,NULL,133,'A','133A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(266,NULL,133,'B','133B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(267,NULL,134,'A','134A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(268,NULL,134,'B','134B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(269,NULL,135,'A','135A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(270,NULL,135,'B','135B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(271,NULL,136,'A','136A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(272,NULL,136,'B','136B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(273,NULL,137,'A','137A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(274,NULL,137,'B','137B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(275,NULL,138,'A','138A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(276,NULL,138,'B','138B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(277,NULL,139,'A','139A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(278,NULL,139,'B','139B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(279,NULL,140,'A','140A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(280,NULL,140,'B','140B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(281,NULL,141,'A','141A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(282,NULL,141,'B','141B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(283,NULL,142,'A','142A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(284,NULL,142,'B','142B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(285,NULL,143,'A','143A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(286,NULL,143,'B','143B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(287,NULL,144,'A','144A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(288,NULL,144,'B','144B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(289,NULL,145,'A','145A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(290,NULL,145,'B','145B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(291,NULL,146,'A','146A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(292,NULL,146,'B','146B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(293,NULL,147,'A','147A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(294,NULL,147,'B','147B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(295,NULL,148,'A','148A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(296,NULL,148,'B','148B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(297,NULL,149,'A','149A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(298,NULL,149,'B','149B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(299,NULL,150,'A','150A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(300,NULL,150,'B','150B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(301,NULL,151,'A','151A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(302,NULL,151,'B','151B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(303,NULL,152,'A','152A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(304,NULL,152,'B','152B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(305,NULL,153,'A','153A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(306,NULL,153,'B','153B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(307,NULL,154,'A','154A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(308,NULL,154,'B','154B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(309,NULL,155,'A','155A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(310,NULL,155,'B','155B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(311,NULL,156,'A','156A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(312,NULL,156,'B','156B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(313,NULL,157,'A','157A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(314,NULL,157,'B','157B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(315,NULL,158,'A','158A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(316,NULL,158,'B','158B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(317,NULL,159,'A','159A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(318,NULL,159,'B','159B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(319,NULL,160,'A','160A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(320,NULL,160,'B','160B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(321,NULL,161,'A','161A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(322,NULL,161,'B','161B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(323,NULL,162,'A','162A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(324,NULL,162,'B','162B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(325,NULL,163,'A','163A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(326,NULL,163,'B','163B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(327,NULL,164,'A','164A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(328,NULL,164,'B','164B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(329,NULL,165,'A','165A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(330,NULL,165,'B','165B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(331,NULL,166,'A','166A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(332,NULL,166,'B','166B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(333,NULL,167,'A','167A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(334,NULL,167,'B','167B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(335,NULL,168,'A','168A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(336,NULL,168,'B','168B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(337,NULL,169,'A','169A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(338,NULL,169,'B','169B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(339,NULL,170,'A','170A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(340,NULL,170,'B','170B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(341,NULL,171,'A','171A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(342,NULL,171,'B','171B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(343,NULL,172,'A','172A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(344,NULL,172,'B','172B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(345,NULL,173,'A','173A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(346,NULL,173,'B','173B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(347,NULL,174,'A','174A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(348,NULL,174,'B','174B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(349,NULL,175,'A','175A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(350,NULL,175,'B','175B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(351,NULL,176,'A','176A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(352,NULL,176,'B','176B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(353,NULL,177,'A','177A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(354,NULL,177,'B','177B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(355,NULL,178,'A','178A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(356,NULL,178,'B','178B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(357,NULL,179,'A','179A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(358,NULL,179,'B','179B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(359,NULL,180,'A','180A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(360,NULL,180,'B','180B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(361,NULL,181,'A','181A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(362,NULL,181,'B','181B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(363,NULL,182,'A','182A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(364,NULL,182,'B','182B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(365,NULL,183,'A','183A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(366,NULL,183,'B','183B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(367,NULL,184,'A','184A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(368,NULL,184,'B','184B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(369,NULL,185,'A','185A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(370,NULL,185,'B','185B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(371,NULL,186,'A','186A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(372,NULL,186,'B','186B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(373,NULL,187,'A','187A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(374,NULL,187,'B','187B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(375,NULL,188,'A','188A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(376,NULL,188,'B','188B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(377,NULL,189,'A','189A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(378,NULL,189,'B','189B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(379,NULL,190,'A','190A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(380,NULL,190,'B','190B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(381,NULL,191,'A','191A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(382,NULL,191,'B','191B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(383,NULL,192,'A','192A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(384,NULL,192,'B','192B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(385,NULL,193,'A','193A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(386,NULL,193,'B','193B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(387,NULL,194,'A','194A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(388,NULL,194,'B','194B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(389,NULL,195,'A','195A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(390,NULL,195,'B','195B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(391,NULL,196,'A','196A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(392,NULL,196,'B','196B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(393,NULL,197,'A','197A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(394,NULL,197,'B','197B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(395,NULL,198,'A','198A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(396,NULL,198,'B','198B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(397,NULL,199,'A','199A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(398,NULL,199,'B','199B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(399,NULL,200,'A','200A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(400,NULL,200,'B','200B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(401,NULL,201,'A','201A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(402,NULL,201,'B','201B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(403,NULL,202,'A','202A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(404,NULL,202,'B','202B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(405,NULL,203,'A','203A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(406,NULL,203,'B','203B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(407,NULL,204,'A','204A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(408,NULL,204,'B','204B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(409,NULL,205,'A','205A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(410,NULL,205,'B','205B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(411,NULL,206,'A','206A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(412,NULL,206,'B','206B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(413,NULL,207,'A','207A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(414,NULL,207,'B','207B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(415,NULL,208,'A','208A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(416,NULL,208,'B','208B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(417,NULL,209,'A','209A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(418,NULL,209,'B','209B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(419,NULL,210,'A','210A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(420,NULL,210,'B','210B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(421,NULL,211,'A','211A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(422,NULL,211,'B','211B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(423,NULL,212,'A','212A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(424,NULL,212,'B','212B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(425,NULL,213,'A','213A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(426,NULL,213,'B','213B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(427,NULL,214,'A','214A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(428,NULL,214,'B','214B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(429,NULL,215,'A','215A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(430,NULL,215,'B','215B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(431,NULL,216,'A','216A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(432,NULL,216,'B','216B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(433,NULL,217,'A','217A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(434,NULL,217,'B','217B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(435,NULL,218,'A','218A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(436,NULL,218,'B','218B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(437,NULL,219,'A','219A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(438,NULL,219,'B','219B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(439,NULL,220,'A','220A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(440,NULL,220,'B','220B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(441,NULL,221,'A','221A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(442,NULL,221,'B','221B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(443,NULL,222,'A','222A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(444,NULL,222,'B','222B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(445,NULL,223,'A','223A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(446,NULL,223,'B','223B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(447,NULL,224,'A','224A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(448,NULL,224,'B','224B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(449,NULL,225,'A','225A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(450,NULL,225,'B','225B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(451,NULL,226,'A','226A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(452,NULL,226,'B','226B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(453,NULL,227,'A','227A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(454,NULL,227,'B','227B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(455,NULL,228,'A','228A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(456,NULL,228,'B','228B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(457,NULL,229,'A','229A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(458,NULL,229,'B','229B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(459,NULL,230,'A','230A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(460,NULL,230,'B','230B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(461,NULL,231,'A','231A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(462,NULL,231,'B','231B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(463,NULL,232,'A','232A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(464,NULL,232,'B','232B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(465,NULL,233,'A','233A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(466,NULL,233,'B','233B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(467,NULL,234,'A','234A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(468,NULL,234,'B','234B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(469,NULL,235,'A','235A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(470,NULL,235,'B','235B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(471,NULL,236,'A','236A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(472,NULL,236,'B','236B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(473,NULL,237,'A','237A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(474,NULL,237,'B','237B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(475,NULL,238,'A','238A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(476,NULL,238,'B','238B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(477,NULL,239,'A','239A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(478,NULL,239,'B','239B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(479,NULL,240,'A','240A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(480,NULL,240,'B','240B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(481,NULL,241,'A','241A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(482,NULL,241,'B','241B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(483,NULL,242,'A','242A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(484,NULL,242,'B','242B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(485,NULL,243,'A','243A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(486,NULL,243,'B','243B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(487,NULL,244,'A','244A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(488,NULL,244,'B','244B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(489,NULL,245,'A','245A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(490,NULL,245,'B','245B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(491,NULL,246,'A','246A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(492,NULL,246,'B','246B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(493,NULL,247,'A','247A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(494,NULL,247,'B','247B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(495,NULL,248,'A','248A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(496,NULL,248,'B','248B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(497,NULL,249,'A','249A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(498,NULL,249,'B','249B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(499,NULL,250,'A','250A','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL),(500,NULL,250,'B','250B','vacio',NULL,'2025-11-24 23:32:07',NULL,NULL);
/*!40000 ALTER TABLE `controles_estacionamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_intentos`
--

DROP TABLE IF EXISTS `login_intentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_intentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `bloqueado_hasta` datetime DEFAULT NULL,
  `ultimo_intento` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `intentos` int(11) DEFAULT 1,
  `exitoso` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  KEY `idx_exitoso` (`exitoso`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Registro de intentos de login para seguridad';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_intentos`
--

LOCK TABLES `login_intentos` WRITE;
/*!40000 ALTER TABLE `login_intentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_intentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_actividad`
--

DROP TABLE IF EXISTS `logs_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs_actividad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL COMMENT 'NULL para acciones del sistema',
  `accion` varchar(255) NOT NULL COMMENT 'Descripción de la acción',
  `modulo` varchar(50) DEFAULT NULL COMMENT 'pagos, usuarios, controles, etc.',
  `tabla_afectada` varchar(50) DEFAULT NULL,
  `registro_id` int(11) DEFAULT NULL COMMENT 'ID del registro afectado',
  `datos_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Estado anterior (UPDATE/DELETE)' CHECK (json_valid(`datos_anteriores`)),
  `datos_nuevos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Estado nuevo (INSERT/UPDATE)' CHECK (json_valid(`datos_nuevos`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_tabla` (`tabla_afectada`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  CONSTRAINT `logs_actividad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Logs de auditoría completos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_actividad`
--

LOCK TABLES `logs_actividad` WRITE;
/*!40000 ALTER TABLE `logs_actividad` DISABLE KEYS */;
INSERT INTO `logs_actividad` VALUES (1,1,'Login exitoso','auth','usuarios',1,NULL,NULL,'192.168.1.100',NULL,'2025-11-04 12:00:00'),(2,2,'Registr├│ pago en efectivo EST-000002','pagos','pagos',2,NULL,NULL,'192.168.1.105',NULL,'2025-09-20 14:00:00'),(3,1,'Aprob├│ comprobante EST-000003','pagos','pagos',3,NULL,NULL,'192.168.1.100',NULL,'2025-10-25 21:00:00'),(4,4,'Consult├│ estado de cuenta','cliente','mensualidades',NULL,NULL,NULL,'192.168.1.120',NULL,'2025-11-03 18:30:00'),(5,7,'Cre├│ solicitud de cambio de cantidad de controles','solicitudes','solicitudes_cambios',1,NULL,NULL,'192.168.1.125',NULL,'2025-11-03 14:00:00');
/*!40000 ALTER TABLE `logs_actividad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensualidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `mes` int(11) NOT NULL COMMENT '1-12',
  `anio` int(11) NOT NULL COMMENT 'Año de la mensualidad',
  `cantidad_controles` int(11) NOT NULL COMMENT 'Cantidad de controles al generar',
  `monto_usd` decimal(10,2) NOT NULL COMMENT 'Monto total en USD',
  `monto_bs` decimal(12,2) NOT NULL COMMENT 'Monto total en Bs',
  `tasa_cambio_id` int(11) NOT NULL COMMENT 'Tasa BCV usada para conversión',
  `estado` enum('pendiente','pagado','vencido') DEFAULT 'pendiente',
  `fecha_vencimiento` date NOT NULL COMMENT 'Último día del mes',
  `fecha_generacion` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Día 5 del mes',
  `bloqueado` tinyint(1) DEFAULT 0 COMMENT 'TRUE con 4+ meses sin pagar',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_mensualidad` (`apartamento_usuario_id`,`mes`,`anio`),
  KEY `tasa_cambio_id` (`tasa_cambio_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha_vencimiento` (`fecha_vencimiento`),
  KEY `idx_mes_anio` (`mes`,`anio`),
  KEY `idx_mensualidad_estado_fecha` (`estado`,`fecha_vencimiento`),
  CONSTRAINT `mensualidades_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mensualidades_ibfk_2` FOREIGN KEY (`tasa_cambio_id`) REFERENCES `tasa_cambio_bcv` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Mensualidades generadas automáticamente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (52,1,12,2025,2,2.00,75.00,9,'pendiente','2025-12-31','2025-11-24 23:41:08',0),(53,1,1,2026,2,2.00,75.00,9,'pendiente','2026-01-31','2025-11-24 23:41:08',0),(54,1,2,2026,2,2.00,75.00,9,'pendiente','2026-02-28','2025-11-24 23:41:08',0),(55,5,12,2025,3,2.00,75.00,9,'pendiente','2025-12-31','2025-11-25 00:37:35',0),(56,5,1,2026,3,2.00,75.00,9,'pendiente','2026-01-31','2025-11-25 00:37:35',0),(57,5,2,2026,3,2.00,75.00,9,'pendiente','2026-02-28','2025-11-25 00:37:35',0),(58,5,3,2026,3,2.00,75.00,9,'pendiente','2026-03-31','2025-11-25 00:37:35',0),(59,5,4,2026,3,2.00,75.00,9,'pendiente','2026-04-30','2025-11-25 00:37:35',0),(60,5,5,2026,3,2.00,75.00,9,'pendiente','2026-05-31','2025-11-25 00:37:35',0),(61,1,3,2026,2,2.00,75.00,9,'pendiente','2026-03-31','2025-11-25 01:53:41',0),(62,1,4,2026,2,2.00,75.00,9,'pendiente','2026-04-30','2025-11-25 01:53:41',0),(63,1,5,2026,2,2.00,75.00,9,'pendiente','2026-05-31','2025-11-25 01:53:41',0),(64,7,12,2025,2,2.00,75.00,9,'pendiente','2025-12-31','2025-11-25 02:03:00',0),(65,7,1,2026,2,2.00,75.00,9,'pendiente','2026-01-31','2025-11-25 02:03:00',0),(66,7,2,2026,2,2.00,75.00,9,'pendiente','2026-02-28','2025-11-25 02:03:00',0),(67,7,3,2026,2,2.00,75.00,9,'pendiente','2026-03-31','2025-11-25 02:03:00',0),(68,7,4,2026,2,2.00,75.00,9,'pendiente','2026-04-30','2025-11-25 02:03:00',0),(69,7,5,2026,2,2.00,75.00,9,'pendiente','2026-05-31','2025-11-25 02:03:00',0),(70,6,12,2025,1,2.00,75.00,9,'pendiente','2025-12-31','2025-11-25 02:31:23',0),(71,6,1,2026,1,2.00,75.00,9,'pendiente','2026-01-31','2025-11-25 02:31:23',0),(72,6,2,2026,1,2.00,75.00,9,'pendiente','2026-02-28','2025-11-25 02:31:23',0),(73,6,3,2026,1,2.00,75.00,9,'pendiente','2026-03-31','2025-11-25 02:31:23',0),(74,6,4,2026,1,2.00,75.00,9,'pendiente','2026-04-30','2025-11-25 02:31:23',0),(75,6,5,2026,1,2.00,75.00,9,'pendiente','2026-05-31','2025-11-25 02:31:23',0),(76,3,12,2025,2,2.00,75.00,9,'pendiente','2025-12-31','2025-11-25 02:45:14',0),(77,3,1,2026,2,2.00,75.00,9,'pendiente','2026-01-31','2025-11-25 02:45:14',0),(78,3,2,2026,2,2.00,75.00,9,'pendiente','2026-02-28','2025-11-25 02:45:14',0),(79,3,3,2026,2,2.00,75.00,9,'pendiente','2026-03-31','2025-11-25 02:45:14',0),(80,3,4,2026,2,2.00,75.00,9,'pendiente','2026-04-30','2025-11-25 02:45:14',0),(81,3,5,2026,2,2.00,75.00,9,'pendiente','2026-05-31','2025-11-25 02:45:14',0),(82,4,12,2025,2,1.00,243.11,10,'pendiente','2025-12-31','2025-11-25 11:41:46',0),(83,4,1,2026,2,1.00,243.11,10,'pendiente','2026-01-31','2025-11-25 11:41:46',0),(84,4,2,2026,2,1.00,243.11,10,'pendiente','2026-02-28','2025-11-25 11:41:46',0),(85,4,3,2026,2,1.00,243.11,10,'pendiente','2026-03-31','2025-11-25 11:41:46',0),(86,4,4,2026,2,1.00,243.11,10,'pendiente','2026-04-30','2025-11-25 11:41:46',0),(87,4,5,2026,2,1.00,243.11,10,'pendiente','2026-05-31','2025-11-25 11:41:46',0),(88,6,6,2026,1,1.00,243.11,10,'pendiente','2026-06-30','2025-11-26 00:14:01',0),(89,6,7,2026,1,1.00,243.11,10,'pendiente','2026-07-31','2025-11-26 00:14:01',0),(90,6,8,2026,1,1.00,243.11,10,'pendiente','2026-08-31','2025-11-26 00:14:01',0),(91,6,9,2026,1,1.00,243.11,10,'pendiente','2026-09-30','2025-11-26 00:14:01',0),(92,6,10,2026,1,1.00,243.11,10,'pendiente','2026-10-31','2025-11-26 00:14:01',0),(93,6,11,2026,1,1.00,243.11,10,'pendiente','2026-11-30','2025-11-26 00:14:01',0),(94,4,6,2026,2,1.00,243.11,10,'pendiente','2026-06-30','2025-11-26 00:23:51',0),(95,4,7,2026,2,1.00,243.11,10,'pendiente','2026-07-31','2025-11-26 00:23:51',0),(96,4,8,2026,2,1.00,243.11,10,'pendiente','2026-08-31','2025-11-26 00:23:51',0),(97,4,9,2026,2,1.00,243.11,10,'pendiente','2026-09-30','2025-11-26 00:23:51',0),(98,4,10,2026,2,1.00,243.11,10,'pendiente','2026-10-31','2025-11-26 00:23:51',0),(99,4,11,2026,2,1.00,243.11,10,'pendiente','2026-11-30','2025-11-26 00:23:51',0),(100,5,6,2026,3,1.00,243.58,12,'pendiente','2026-06-30','2025-11-26 22:52:28',0),(101,5,7,2026,3,1.00,243.58,12,'pendiente','2026-07-31','2025-11-26 22:52:28',0),(102,5,8,2026,3,1.00,243.58,12,'pendiente','2026-08-31','2025-11-26 22:52:28',0),(103,5,9,2026,3,1.00,243.58,12,'pendiente','2026-09-30','2025-11-26 22:52:28',0),(104,5,10,2026,3,1.00,243.58,12,'pendiente','2026-10-31','2025-11-26 22:52:28',0),(105,5,11,2026,3,1.00,243.58,12,'pendiente','2026-11-30','2025-11-26 22:52:28',0);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `tipo` enum('alerta_3_meses','alerta_bloqueo','comprobante_rechazado','pago_aprobado','solicitud_aprobada','solicitud_rechazada','bienvenida','password_cambiado') NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensaje` text NOT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_lectura` datetime DEFAULT NULL,
  `email_enviado` tinyint(1) DEFAULT 0,
  `fecha_email` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_leido` (`usuario_id`,`leido`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_fecha_creacion` (`fecha_creacion`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Notificaciones del sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES (1,5,'bienvenida','Bienvenido al Sistema de Estacionamiento','Hola Roberto, bienvenido al sistema. Por favor, cambia tu contrase??a temporal y completa tu perfil.',0,'2025-11-14 23:25:36',NULL,1,NULL),(2,7,'alerta_3_meses','Alerta: 3 Meses de Mora','Estimado Juan, tiene 3 mensualidades pendientes. Por favor, realice el pago para evitar bloqueo de controles.',0,'2025-11-14 23:25:36',NULL,1,NULL),(3,4,'pago_aprobado','Pago Aprobado','Su pago de Septiembre 2025 ha sido aprobado. Recibo: EST-000001',1,'2025-11-14 23:25:36',NULL,1,NULL);
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago_mensualidad`
--

DROP TABLE IF EXISTS `pago_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago_mensualidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pago_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  `monto_aplicado_usd` decimal(10,2) NOT NULL COMMENT 'Monto aplicado a esta mensualidad',
  `fecha_aplicacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pago_mensualidad` (`pago_id`,`mensualidad_id`),
  KEY `idx_pago` (`pago_id`),
  KEY `idx_mensualidad` (`mensualidad_id`),
  CONSTRAINT `pago_mensualidad_ibfk_1` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pago_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Relación pagos-mensualidades';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago_mensualidad`
--

LOCK TABLES `pago_mensualidad` WRITE;
/*!40000 ALTER TABLE `pago_mensualidad` DISABLE KEYS */;
INSERT INTO `pago_mensualidad` VALUES (6,13,52,5.00,'2025-11-26 01:50:04'),(7,14,52,5.00,'2025-11-26 01:50:04');
/*!40000 ALTER TABLE `pago_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `numero_recibo` varchar(20) NOT NULL COMMENT 'Formato: EST-000001',
  `monto_usd` decimal(10,2) NOT NULL,
  `monto_bs` decimal(12,2) NOT NULL,
  `tasa_cambio_id` int(11) NOT NULL,
  `moneda_pago` enum('usd_efectivo','bs_transferencia','bs_efectivo') NOT NULL,
  `fecha_pago` timestamp NOT NULL DEFAULT current_timestamp(),
  `comprobante_ruta` varchar(255) DEFAULT NULL COMMENT 'Path al archivo de comprobante',
  `estado_comprobante` enum('pendiente','aprobado','rechazado','no_aplica') DEFAULT 'no_aplica',
  `motivo_rechazo` text DEFAULT NULL,
  `registrado_por` int(11) NOT NULL COMMENT 'Usuario que registró el pago',
  `aprobado_por` int(11) DEFAULT NULL COMMENT 'Usuario que aprobó el comprobante',
  `fecha_aprobacion` datetime DEFAULT NULL,
  `es_reconexion` tinyint(1) DEFAULT 0,
  `monto_reconexion_usd` decimal(10,2) DEFAULT 2.00,
  `google_sheets_sync` tinyint(1) DEFAULT 0,
  `fecha_sync` datetime DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_recibo` (`numero_recibo`),
  KEY `apartamento_usuario_id` (`apartamento_usuario_id`),
  KEY `tasa_cambio_id` (`tasa_cambio_id`),
  KEY `registrado_por` (`registrado_por`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_numero_recibo` (`numero_recibo`),
  KEY `idx_fecha_pago` (`fecha_pago`),
  KEY `idx_estado_comprobante` (`estado_comprobante`),
  KEY `idx_moneda_pago` (`moneda_pago`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`tasa_cambio_id`) REFERENCES `tasa_cambio_bcv` (`id`),
  CONSTRAINT `pagos_ibfk_3` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `pagos_ibfk_4` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Registro completo de pagos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,1,'EST-000001',2.00,73.70,5,'bs_transferencia','2025-09-15 18:30:00','uploads/comprobantes/maria_sept_2025.jpg','aprobado',NULL,2,2,'2025-09-15 15:00:00',0,2.00,1,NULL,NULL),(2,5,'EST-000002',3.00,110.55,5,'usd_efectivo','2025-09-20 14:00:00',NULL,'no_aplica',NULL,2,NULL,NULL,0,2.00,1,NULL,NULL),(3,3,'EST-000003',4.00,148.80,6,'bs_transferencia','2025-10-25 20:45:00','uploads/comprobantes/laura_oct_2025.jpg','aprobado',NULL,2,1,'2025-10-25 17:00:00',0,2.00,1,NULL,NULL),(4,5,'EST-000004',3.00,111.60,6,'usd_efectivo','2025-10-22 15:30:00',NULL,'no_aplica',NULL,2,NULL,NULL,0,2.00,1,NULL,NULL),(5,1,'TEST-20251126-024457',5.00,1217.90,12,'','2025-11-26 01:44:57','/uploads/comprobantes/test_20251126_024457.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(7,1,'TEST-20251126-024559',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:45:59','/uploads/comprobantes/test_20251126_024559.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(9,1,'TEST-20251126-024718',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:47:18','/uploads/comprobantes/test_20251126_024718.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(11,1,'TEST-024811-475',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:48:11','/uploads/comprobantes/test_20251126_024811.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(12,1,'TEST-024811-679',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:48:11','/uploads/comprobantes/test_20251126_024811.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(13,1,'TEST-025004-635',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:50:04','/uploads/comprobantes/test_20251126_025004.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL),(14,1,'TEST-025004-535',5.00,1217.90,12,'bs_transferencia','2025-11-26 01:50:04','/uploads/comprobantes/test_20251126_025004.pdf','pendiente',NULL,4,NULL,NULL,0,2.00,0,NULL,NULL);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `codigo` varchar(6) NOT NULL COMMENT 'Código de 6 dígitos',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_expiracion` timestamp NULL DEFAULT NULL COMMENT 'Expira en 15 minutos',
  `usado` tinyint(1) DEFAULT 0 COMMENT 'TRUE después de usar el código',
  `intentos_validacion` int(11) DEFAULT 0 COMMENT 'Máximo 3 intentos',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_codigo` (`codigo`),
  KEY `idx_email` (`email`),
  KEY `idx_fecha_expiracion` (`fecha_expiracion`),
  KEY `idx_usado` (`usado`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tokens para recuperación de contraseña';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_cambios`
--

DROP TABLE IF EXISTS `solicitudes_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes_cambios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `tipo_solicitud` enum('cambio_cantidad_controles','suspension_control','desactivacion_control') NOT NULL,
  `cantidad_controles_nueva` int(11) DEFAULT NULL COMMENT 'Solo para cambio_cantidad_controles',
  `control_id` int(11) DEFAULT NULL COMMENT 'Solo para suspension/desactivacion',
  `motivo` text NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada') DEFAULT 'pendiente',
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `aprobado_por` int(11) DEFAULT NULL,
  `fecha_respuesta` datetime DEFAULT NULL,
  `observaciones` text DEFAULT NULL COMMENT 'Comentarios del operador/admin',
  PRIMARY KEY (`id`),
  KEY `apartamento_usuario_id` (`apartamento_usuario_id`),
  KEY `control_id` (`control_id`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_estado` (`estado`),
  KEY `idx_tipo_solicitud` (`tipo_solicitud`),
  KEY `idx_fecha_solicitud` (`fecha_solicitud`),
  CONSTRAINT `solicitudes_cambios_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solicitudes_cambios_ibfk_2` FOREIGN KEY (`control_id`) REFERENCES `controles_estacionamiento` (`id`) ON DELETE SET NULL,
  CONSTRAINT `solicitudes_cambios_ibfk_3` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Solicitudes de cambios en controles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_cambios`
--

LOCK TABLES `solicitudes_cambios` WRITE;
/*!40000 ALTER TABLE `solicitudes_cambios` DISABLE KEYS */;
INSERT INTO `solicitudes_cambios` VALUES (1,4,'cambio_cantidad_controles',3,NULL,'Necesito un control adicional para segundo veh├¡culo','pendiente','2025-11-03 14:00:00',NULL,NULL,NULL);
/*!40000 ALTER TABLE `solicitudes_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasa_cambio_bcv`
--

DROP TABLE IF EXISTS `tasa_cambio_bcv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasa_cambio_bcv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_usd_bs` decimal(10,4) NOT NULL COMMENT 'Tasa oficial BCV (Ej: 36.5000)',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `registrado_por` int(11) DEFAULT NULL COMMENT 'Usuario que actualizó la tasa',
  `fuente` varchar(100) DEFAULT 'Manual' COMMENT 'Manual o API',
  PRIMARY KEY (`id`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_fecha_registro` (`fecha_registro`),
  CONSTRAINT `tasa_cambio_bcv_ibfk_1` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Historial de tasas BCV';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasa_cambio_bcv`
--

LOCK TABLES `tasa_cambio_bcv` WRITE;
/*!40000 ALTER TABLE `tasa_cambio_bcv` DISABLE KEYS */;
INSERT INTO `tasa_cambio_bcv` VALUES (3,36.4500,'2025-01-01 14:00:00',1,'Manual'),(4,36.5200,'2025-01-15 14:00:00',1,'Manual'),(5,36.6000,'2025-02-01 14:00:00',1,'Manual'),(6,36.7500,'2025-03-01 14:00:00',1,'Manual'),(7,36.8500,'2025-10-01 14:00:00',1,'Manual'),(8,37.2000,'2025-11-01 14:00:00',1,'Manual'),(9,37.5000,'2025-11-04 13:00:00',1,'API'),(10,243.1105,'2025-11-25 02:50:42',1,'BCV CRON Manual'),(11,243.0805,'2025-11-26 00:25:32',2,'BCV_WEB'),(12,243.5805,'2025-11-26 00:25:34',2,'BCV_WEB'),(13,243.4605,'2025-11-26 22:53:42',2,'BCV_WEB'),(14,243.5705,'2025-11-26 22:53:44',2,'BCV_WEB'),(15,243.1305,'2025-11-26 22:54:04',2,'BCV_WEB'),(16,243.0005,'2025-11-26 22:54:06',2,'BCV_WEB'),(17,242.9905,'2025-11-26 22:54:11',2,'BCV_WEB'),(18,242.6905,'2025-11-26 22:54:12',2,'BCV_WEB'),(19,244.6504,'2025-11-26 22:58:40',1,'BCV Automático');
/*!40000 ALTER TABLE `tasa_cambio_bcv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL COMMENT 'Email del usuario (puede estar vacío)',
  `password` varchar(255) NOT NULL COMMENT 'Hash BCRYPT',
  `telefono` varchar(20) DEFAULT NULL,
  `cedula` varchar(20) DEFAULT NULL COMMENT 'Cédula de identidad',
  `rol` enum('cliente','operador','consultor','administrador') NOT NULL DEFAULT 'cliente',
  `activo` tinyint(1) DEFAULT 1,
  `intentos_fallidos` int(11) DEFAULT 0 COMMENT 'Máximo 5 intentos',
  `bloqueado_hasta` datetime DEFAULT NULL COMMENT 'Bloqueo temporal por intentos fallidos',
  `primer_acceso` tinyint(1) DEFAULT 1 COMMENT 'TRUE si es primera vez que ingresa',
  `password_temporal` tinyint(1) DEFAULT 1 COMMENT 'TRUE si password fue generado por admin',
  `perfil_completo` tinyint(1) DEFAULT 0 COMMENT 'TRUE cuando completa datos personales',
  `exonerado` tinyint(1) DEFAULT 0 COMMENT 'Usuarios exonerados no pagan mensualidad',
  `motivo_exoneracion` text DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_acceso` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_rol` (`rol`),
  KEY `idx_activo` (`activo`),
  KEY `idx_cedula` (`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Usuarios del sistema con 4 roles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Ing. Miguel Sánchez','admin@estacionamiento.local','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 424 1234567',NULL,'administrador',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36','2025-11-26 18:58:04'),(2,'Carmen Méndez','operador@estacionamiento.local','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 414 2345678',NULL,'operador',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36','2025-11-26 18:50:00'),(3,'Sr. Alberto Rivas','consultor@estacionamiento.local','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 412 3456789',NULL,'consultor',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36',NULL),(4,'María González','maria.gonzalez@gmail.com','$2y$10$hMt5H2g6ij4upSfldEFpbu5993rNBQ6WnQ0nRDJSn1RLBJ5jEUenS','+58 426 4567890',NULL,'cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36','2025-11-24 19:58:59'),(5,'Roberto Díaz','roberto.diaz@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 414 5678901',NULL,'cliente',1,0,NULL,1,1,0,0,NULL,'2025-11-14 23:25:36',NULL),(6,'Laura Morales','laura.morales@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 424 6789012',NULL,'cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36',NULL),(7,'Juan Pérez','juan.perez@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 412 7890123',NULL,'cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36',NULL),(8,'Ana Rodríguez','ana.rodriguez@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 426 8901234',NULL,'cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36',NULL),(9,'Carlos Martínez','carlos.martinez@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 414 9012345',NULL,'cliente',1,0,NULL,0,0,1,1,NULL,'2025-11-14 23:25:36',NULL),(10,'Elena Silva','elena.silva@gmail.com','$2y$10$3y9g0fdZvIHwilFk/qqJie61aIJ6XHBU04cErmnmFrq22Z8xu.I26','+58 424 0123456',NULL,'cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-14 23:25:36',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vista_controles_vacios`
--

DROP TABLE IF EXISTS `vista_controles_vacios`;
/*!50001 DROP VIEW IF EXISTS `vista_controles_vacios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vista_controles_vacios` AS SELECT
 1 AS `id`,
  1 AS `posicion_numero`,
  1 AS `receptor`,
  1 AS `numero_control_completo`,
  1 AS `estado` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vista_morosidad`
--

DROP TABLE IF EXISTS `vista_morosidad`;
/*!50001 DROP VIEW IF EXISTS `vista_morosidad`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vista_morosidad` AS SELECT
 1 AS `usuario_id`,
  1 AS `nombre_completo`,
  1 AS `email`,
  1 AS `telefono`,
  1 AS `apartamento`,
  1 AS `cantidad_controles`,
  1 AS `meses_pendientes`,
  1 AS `total_deuda_usd`,
  1 AS `total_deuda_bs`,
  1 AS `primer_mes_pendiente`,
  1 AS `ultimo_mes_pendiente`,
  1 AS `estado_morosidad` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_controles_vacios`
--

/*!50001 DROP VIEW IF EXISTS `vista_controles_vacios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_controles_vacios` AS select `c`.`id` AS `id`,`c`.`posicion_numero` AS `posicion_numero`,`c`.`receptor` AS `receptor`,`c`.`numero_control_completo` AS `numero_control_completo`,`c`.`estado` AS `estado` from `controles_estacionamiento` `c` where `c`.`estado` = 'vacio' and `c`.`apartamento_usuario_id` is null order by `c`.`posicion_numero`,`c`.`receptor` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_morosidad`
--

/*!50001 DROP VIEW IF EXISTS `vista_morosidad`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_morosidad` AS select `u`.`id` AS `usuario_id`,`u`.`nombre_completo` AS `nombre_completo`,`u`.`email` AS `email`,`u`.`telefono` AS `telefono`,concat(`a`.`bloque`,'-',`a`.`numero_apartamento`) AS `apartamento`,`au`.`cantidad_controles` AS `cantidad_controles`,count(`m`.`id`) AS `meses_pendientes`,sum(`m`.`monto_usd`) AS `total_deuda_usd`,sum(`m`.`monto_bs`) AS `total_deuda_bs`,min(`m`.`fecha_vencimiento`) AS `primer_mes_pendiente`,max(`m`.`fecha_vencimiento`) AS `ultimo_mes_pendiente`,case when count(`m`.`id`) >= 4 then 'Bloqueado' when count(`m`.`id`) >= 3 then 'Alerta' else 'Normal' end AS `estado_morosidad` from (((`usuarios` `u` join `apartamento_usuario` `au` on(`au`.`usuario_id` = `u`.`id` and `au`.`activo` = 1)) join `apartamentos` `a` on(`a`.`id` = `au`.`apartamento_id`)) join `mensualidades` `m` on(`m`.`apartamento_usuario_id` = `au`.`id` and `m`.`estado` in ('pendiente','vencido'))) where `u`.`rol` = 'cliente' and `u`.`activo` = 1 and `u`.`exonerado` = 0 group by `u`.`id`,`u`.`nombre_completo`,`u`.`email`,`u`.`telefono`,`a`.`bloque`,`a`.`numero_apartamento`,`au`.`cantidad_controles` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-26 19:01:40
