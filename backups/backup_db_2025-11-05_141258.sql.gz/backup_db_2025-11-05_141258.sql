-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: estacionamiento_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apartamento_usuario`
--

DROP TABLE IF EXISTS `apartamento_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamento_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `cantidad_controles` int(11) DEFAULT 0 COMMENT 'N├║mero de controles asignados',
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `activo` tinyint(1) DEFAULT 1 COMMENT 'FALSE cuando se muda o transfiere',
  PRIMARY KEY (`id`),
  KEY `idx_apartamento` (`apartamento_id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `apartamento_usuario_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `apartamento_usuario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Relaci├│n apartamentos-usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamento_usuario`
--

LOCK TABLES `apartamento_usuario` WRITE;
/*!40000 ALTER TABLE `apartamento_usuario` DISABLE KEYS */;
INSERT INTO `apartamento_usuario` VALUES (1,6,4,2,'2025-11-04 18:55:13',1),(2,7,5,1,'2025-11-04 18:55:13',1),(3,8,6,2,'2025-11-04 18:55:13',1),(4,1,9,3,'2025-11-04 18:55:13',0),(5,2,8,3,'2025-11-04 18:55:13',1),(6,3,9,1,'2025-11-04 18:55:13',1),(7,4,10,2,'2025-11-04 18:55:13',1);
/*!40000 ALTER TABLE `apartamento_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartamentos`
--

DROP TABLE IF EXISTS `apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloque` varchar(10) NOT NULL COMMENT 'Bloques: 27, 28, 29, 30, 31, 32',
  `escalera` varchar(5) NOT NULL COMMENT 'Escaleras: A, B, C',
  `piso` int(11) NOT NULL COMMENT 'Piso del apartamento',
  `numero_apartamento` varchar(10) NOT NULL COMMENT 'N├║mero del apto (Ej: 501, 502)',
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_apartamento` (`bloque`,`escalera`,`piso`,`numero_apartamento`),
  KEY `idx_bloque` (`bloque`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Apartamentos de los bloques 27-32';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamentos`
--

LOCK TABLES `apartamentos` WRITE;
/*!40000 ALTER TABLE `apartamentos` DISABLE KEYS */;
INSERT INTO `apartamentos` VALUES (1,'27','A',3,'501',1,'2025-11-04 18:55:13'),(2,'27','A',3,'502',1,'2025-11-04 18:55:13'),(3,'27','B',3,'301',1,'2025-11-04 18:55:13'),(4,'28','A',4,'401',1,'2025-11-04 18:55:13'),(5,'28','B',2,'201',1,'2025-11-04 18:55:13'),(6,'29','A',5,'501',1,'2025-11-04 18:55:13'),(7,'29','B',6,'601',1,'2025-11-04 18:55:13'),(8,'30','A',3,'301',1,'2025-11-04 18:55:13'),(9,'30','C',4,'402',1,'2025-11-04 18:55:13'),(10,'31','A',2,'201',1,'2025-11-04 18:55:13'),(11,'32','B',5,'503',1,'2025-11-04 18:55:13');
/*!40000 ALTER TABLE `apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_cron`
--

DROP TABLE IF EXISTS `configuracion_cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tarea` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `hora_ejecucion` time NOT NULL,
  `frecuencia` enum('diaria','semanal','mensual') DEFAULT 'diaria',
  `dia_mes` int(11) DEFAULT NULL COMMENT 'Para tareas mensuales (1-31)',
  `ultima_ejecucion` datetime DEFAULT NULL,
  `proxima_ejecucion` datetime DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_nombre` (`nombre_tarea`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_cron`
--

LOCK TABLES `configuracion_cron` WRITE;
/*!40000 ALTER TABLE `configuracion_cron` DISABLE KEYS */;
INSERT INTO `configuracion_cron` VALUES (1,'generar_mensualidades','Generar mensualidades automßticamente',1,'00:00:00','mensual',5,NULL,NULL,'2025-11-05 14:07:20','2025-11-05 14:07:20'),(2,'verificar_bloqueos','Verificar y aplicar bloqueos por morosidad',1,'01:00:00','diaria',NULL,NULL,NULL,'2025-11-05 14:07:20','2025-11-05 14:07:20'),(3,'enviar_notificaciones','Enviar notificaciones de pago pendiente',1,'09:00:00','diaria',NULL,NULL,NULL,'2025-11-05 14:07:20','2025-11-05 14:07:20'),(4,'actualizar_tasa_bcv','Actualizar tasa de cambio BCV automßticamente',1,'10:00:00','diaria',NULL,NULL,NULL,'2025-11-05 14:07:20','2025-11-05 14:07:20'),(5,'backup_database','Backup automßtico de base de datos',1,'02:00:00','diaria',NULL,NULL,NULL,'2025-11-05 16:37:54','2025-11-05 16:37:54');
/*!40000 ALTER TABLE `configuracion_cron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_tarifas`
--

DROP TABLE IF EXISTS `configuracion_tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_tarifas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto_mensual_usd` decimal(10,2) NOT NULL DEFAULT 1.00 COMMENT 'Tarifa en USD por control',
  `meses_bloqueo` int(11) DEFAULT 2,
  `fecha_vigencia_inicio` date NOT NULL,
  `fecha_vigencia_fin` date DEFAULT NULL COMMENT 'NULL = vigencia actual',
  `activo` tinyint(1) DEFAULT 1,
  `creado_por` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_vigencia` (`fecha_vigencia_inicio`,`fecha_vigencia_fin`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `configuracion_tarifas_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tarifas mensuales configurables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_tarifas`
--

LOCK TABLES `configuracion_tarifas` WRITE;
/*!40000 ALTER TABLE `configuracion_tarifas` DISABLE KEYS */;
INSERT INTO `configuracion_tarifas` VALUES (1,1.00,2,'2025-01-01',NULL,0,NULL,'2025-11-04 18:55:00'),(2,1.00,2,'2025-11-04',NULL,0,1,'2025-11-05 02:11:34'),(3,1.00,2,'2025-11-04',NULL,0,1,'2025-11-05 02:11:46'),(4,1.00,2,'2025-11-05',NULL,0,1,'2025-11-05 13:16:45'),(5,2.00,2,'2025-11-05',NULL,0,1,'2025-11-05 13:16:57'),(6,1.00,2,'2025-11-05',NULL,0,1,'2025-11-05 13:17:12'),(7,1.00,4,'2025-11-05',NULL,1,1,'2025-11-05 13:29:17');
/*!40000 ALTER TABLE `configuracion_tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controles_estacionamiento`
--

DROP TABLE IF EXISTS `controles_estacionamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `controles_estacionamiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) DEFAULT NULL COMMENT 'NULL = control vac├¡o/sin asignar',
  `posicion_numero` int(11) NOT NULL COMMENT 'Posici├│n f├¡sica: 1-250',
  `receptor` enum('A','B') NOT NULL COMMENT 'Receptor A o B',
  `numero_control_completo` varchar(10) NOT NULL COMMENT 'Ej: 1A, 15B, 250A',
  `estado` enum('activo','suspendido','desactivado','perdido','bloqueado','vacio') DEFAULT 'vacio',
  `motivo_estado` text DEFAULT NULL COMMENT 'Motivo de suspensi├│n, desactivaci├│n, etc.',
  `fecha_estado` timestamp NOT NULL DEFAULT current_timestamp(),
  `aprobado_por` int(11) DEFAULT NULL COMMENT 'Usuario que aprob├│ cambio de estado',
  `fecha_asignacion` datetime DEFAULT NULL COMMENT 'Fecha cuando se asign├│ a un usuario',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_control_completo` (`numero_control_completo`),
  UNIQUE KEY `unique_posicion_receptor` (`posicion_numero`,`receptor`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_estado` (`estado`),
  KEY `idx_posicion` (`posicion_numero`),
  KEY `idx_receptor` (`receptor`),
  KEY `idx_control_apartamento` (`apartamento_usuario_id`,`estado`),
  CONSTRAINT `controles_estacionamiento_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE SET NULL,
  CONSTRAINT `controles_estacionamiento_ibfk_2` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='500 controles totales (250├ù2 receptores)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controles_estacionamiento`
--

LOCK TABLES `controles_estacionamiento` WRITE;
/*!40000 ALTER TABLE `controles_estacionamiento` DISABLE KEYS */;
INSERT INTO `controles_estacionamiento` VALUES (1,1,15,'A','15A','bloqueado','moroso','2025-11-04 20:29:58',NULL,'2024-12-01 10:00:00'),(2,1,15,'B','15B','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-12-01 10:00:00'),(3,2,127,'A','127A','activo',NULL,'2025-11-04 18:55:13',NULL,'2025-01-15 14:30:00'),(4,3,45,'A','45A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-10-10 09:00:00'),(5,3,45,'B','45B','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-10-10 09:00:00'),(6,4,30,'A','30A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-11-05 11:00:00'),(7,4,30,'B','30B','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-11-05 11:00:00'),(8,5,50,'A','50A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-09-20 15:00:00'),(9,5,50,'B','50B','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-09-20 15:00:00'),(10,5,51,'A','51A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-09-20 15:00:00'),(11,6,60,'A','60A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-08-15 10:00:00'),(12,7,75,'A','75A','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-12-10 12:00:00'),(13,7,75,'B','75B','activo',NULL,'2025-11-04 18:55:13',NULL,'2024-12-10 12:00:00'),(14,NULL,1,'A','1A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(15,NULL,1,'B','1B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(16,NULL,2,'A','2A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(17,NULL,2,'B','2B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(18,NULL,3,'A','3A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(19,NULL,3,'B','3B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(20,NULL,4,'A','4A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(21,NULL,4,'B','4B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(22,NULL,5,'A','5A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(23,NULL,5,'B','5B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(24,NULL,6,'A','6A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(25,NULL,6,'B','6B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(26,NULL,7,'A','7A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(27,NULL,7,'B','7B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(28,NULL,8,'A','8A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(29,NULL,8,'B','8B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(30,NULL,9,'A','9A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(31,NULL,9,'B','9B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(32,NULL,10,'A','10A','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL),(33,NULL,10,'B','10B','vacio',NULL,'2025-11-04 18:55:13',NULL,NULL);
/*!40000 ALTER TABLE `controles_estacionamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_intentos`
--

DROP TABLE IF EXISTS `login_intentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_intentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `intentos` int(11) DEFAULT 0,
  `ultimo_intento` datetime NOT NULL,
  `bloqueado_hasta` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_bloqueado` (`bloqueado_hasta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_intentos`
--

LOCK TABLES `login_intentos` WRITE;
/*!40000 ALTER TABLE `login_intentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_intentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_actividad`
--

DROP TABLE IF EXISTS `logs_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs_actividad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL COMMENT 'NULL para acciones del sistema',
  `accion` varchar(255) NOT NULL COMMENT 'Descripci├│n de la acci├│n',
  `modulo` varchar(50) DEFAULT NULL COMMENT 'pagos, usuarios, controles, etc.',
  `tabla_afectada` varchar(50) DEFAULT NULL,
  `registro_id` int(11) DEFAULT NULL COMMENT 'ID del registro afectado',
  `datos_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Estado anterior (UPDATE/DELETE)' CHECK (json_valid(`datos_anteriores`)),
  `datos_nuevos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Estado nuevo (INSERT/UPDATE)' CHECK (json_valid(`datos_nuevos`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_tabla` (`tabla_afectada`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  CONSTRAINT `logs_actividad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Logs de auditor├¡a completos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_actividad`
--

LOCK TABLES `logs_actividad` WRITE;
/*!40000 ALTER TABLE `logs_actividad` DISABLE KEYS */;
INSERT INTO `logs_actividad` VALUES (1,1,'Login exitoso','auth','usuarios',1,NULL,NULL,'192.168.1.100',NULL,'2025-11-04 12:00:00'),(2,2,'Registr├│ pago en efectivo EST-000002','pagos','pagos',2,NULL,NULL,'192.168.1.105',NULL,'2025-09-20 14:00:00'),(3,1,'Aprob├│ comprobante EST-000003','pagos','pagos',3,NULL,NULL,'192.168.1.100',NULL,'2025-10-25 21:00:00'),(4,4,'Consult├│ estado de cuenta','cliente','mensualidades',NULL,NULL,NULL,'192.168.1.120',NULL,'2025-11-03 18:30:00'),(5,7,'Cre├│ solicitud de cambio de cantidad de controles','solicitudes','solicitudes_cambios',1,NULL,NULL,'192.168.1.125',NULL,'2025-11-03 14:00:00');
/*!40000 ALTER TABLE `logs_actividad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidades`
--

DROP TABLE IF EXISTS `mensualidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensualidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `mes` int(11) NOT NULL COMMENT '1-12',
  `anio` int(11) NOT NULL COMMENT 'A├▒o de la mensualidad',
  `cantidad_controles` int(11) NOT NULL COMMENT 'Cantidad de controles al generar',
  `monto_usd` decimal(10,2) NOT NULL COMMENT 'Monto total en USD',
  `monto_bs` decimal(12,2) NOT NULL COMMENT 'Monto total en Bs',
  `tasa_cambio_id` int(11) NOT NULL COMMENT 'Tasa BCV usada para conversi├│n',
  `estado` enum('pendiente','pagado','vencido') DEFAULT 'pendiente',
  `fecha_vencimiento` date NOT NULL COMMENT '├Ültimo d├¡a del mes',
  `fecha_generacion` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'D├¡a 5 del mes',
  `bloqueado` tinyint(1) DEFAULT 0 COMMENT 'TRUE con 4+ meses sin pagar',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_mensualidad` (`apartamento_usuario_id`,`mes`,`anio`),
  KEY `tasa_cambio_id` (`tasa_cambio_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha_vencimiento` (`fecha_vencimiento`),
  KEY `idx_mes_anio` (`mes`,`anio`),
  KEY `idx_mensualidad_estado_fecha` (`estado`,`fecha_vencimiento`),
  CONSTRAINT `mensualidades_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mensualidades_ibfk_2` FOREIGN KEY (`tasa_cambio_id`) REFERENCES `tasa_cambio_bcv` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Mensualidades generadas autom├íticamente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidades`
--

LOCK TABLES `mensualidades` WRITE;
/*!40000 ALTER TABLE `mensualidades` DISABLE KEYS */;
INSERT INTO `mensualidades` VALUES (1,1,9,2025,2,2.00,73.70,5,'vencido','2025-09-30','2025-09-05 04:05:00',0),(2,2,9,2025,1,1.00,36.85,5,'vencido','2025-09-30','2025-09-05 04:05:00',0),(3,3,9,2025,2,2.00,73.70,5,'pagado','2025-09-30','2025-09-05 04:05:00',0),(4,4,9,2025,2,2.00,73.70,5,'vencido','2025-09-30','2025-09-05 04:05:00',0),(5,5,9,2025,3,3.00,110.55,5,'pagado','2025-09-30','2025-09-05 04:05:00',0),(6,7,9,2025,2,2.00,73.70,5,'vencido','2025-09-30','2025-09-05 04:05:00',0),(7,1,10,2025,2,2.00,74.40,6,'vencido','2025-10-31','2025-10-05 04:05:00',0),(8,2,10,2025,1,1.00,37.20,6,'vencido','2025-10-31','2025-10-05 04:05:00',0),(9,3,10,2025,2,2.00,74.40,6,'pagado','2025-10-31','2025-10-05 04:05:00',0),(10,4,10,2025,2,2.00,74.40,6,'vencido','2025-10-31','2025-10-05 04:05:00',0),(11,5,10,2025,3,3.00,111.60,6,'pagado','2025-10-31','2025-10-05 04:05:00',0),(12,7,10,2025,2,2.00,74.40,6,'vencido','2025-10-31','2025-10-05 04:05:00',0),(13,1,11,2025,2,2.00,75.00,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0),(14,2,11,2025,1,1.00,37.50,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0),(15,3,11,2025,2,2.00,75.00,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0),(16,4,11,2025,2,2.00,75.00,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0),(17,5,11,2025,3,3.00,112.50,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0),(18,7,11,2025,2,2.00,75.00,7,'pendiente','2025-11-30','2025-11-05 04:05:00',0);
/*!40000 ALTER TABLE `mensualidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `tipo` enum('alerta_3_meses','alerta_bloqueo','comprobante_rechazado','pago_aprobado','solicitud_aprobada','solicitud_rechazada','bienvenida','password_cambiado') NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensaje` text NOT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_lectura` datetime DEFAULT NULL,
  `email_enviado` tinyint(1) DEFAULT 0,
  `fecha_email` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario_leido` (`usuario_id`,`leido`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_fecha_creacion` (`fecha_creacion`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Notificaciones del sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES (1,5,'bienvenida','Bienvenido al Sistema de Estacionamiento','Hola Roberto, bienvenido al sistema. Por favor, cambia tu contrase├▒a temporal y completa tu perfil.',0,'2025-11-04 18:55:13',NULL,1,NULL),(2,7,'alerta_3_meses','Alerta: 3 Meses de Mora','Estimado Juan, tiene 3 mensualidades pendientes. Por favor, realice el pago para evitar bloqueo de controles.',0,'2025-11-04 18:55:13',NULL,1,NULL),(3,4,'pago_aprobado','Pago Aprobado','Su pago de Septiembre 2025 ha sido aprobado. Recibo: EST-000001',1,'2025-11-04 18:55:13',NULL,1,NULL);
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago_mensualidad`
--

DROP TABLE IF EXISTS `pago_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago_mensualidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pago_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  `monto_aplicado_usd` decimal(10,2) NOT NULL COMMENT 'Monto aplicado a esta mensualidad',
  `fecha_aplicacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pago_mensualidad` (`pago_id`,`mensualidad_id`),
  KEY `idx_pago` (`pago_id`),
  KEY `idx_mensualidad` (`mensualidad_id`),
  CONSTRAINT `pago_mensualidad_ibfk_1` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pago_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Relaci├│n pagos-mensualidades';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago_mensualidad`
--

LOCK TABLES `pago_mensualidad` WRITE;
/*!40000 ALTER TABLE `pago_mensualidad` DISABLE KEYS */;
INSERT INTO `pago_mensualidad` VALUES (1,1,1,2.00,'2025-11-04 18:55:13'),(2,2,5,3.00,'2025-11-04 18:55:13'),(3,3,3,2.00,'2025-11-04 18:55:13'),(4,3,9,2.00,'2025-11-04 18:55:13'),(5,4,11,3.00,'2025-11-04 18:55:13');
/*!40000 ALTER TABLE `pago_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `numero_recibo` varchar(20) NOT NULL COMMENT 'Formato: EST-000001',
  `monto_usd` decimal(10,2) NOT NULL,
  `monto_bs` decimal(12,2) NOT NULL,
  `tasa_cambio_id` int(11) NOT NULL,
  `moneda_pago` enum('usd_efectivo','bs_transferencia','bs_efectivo') NOT NULL,
  `fecha_pago` timestamp NOT NULL DEFAULT current_timestamp(),
  `comprobante_ruta` varchar(255) DEFAULT NULL COMMENT 'Path al archivo de comprobante',
  `estado_comprobante` enum('pendiente','aprobado','rechazado','no_aplica') DEFAULT 'no_aplica',
  `motivo_rechazo` text DEFAULT NULL,
  `registrado_por` int(11) NOT NULL COMMENT 'Usuario que registr├│ el pago',
  `aprobado_por` int(11) DEFAULT NULL COMMENT 'Usuario que aprob├│ el comprobante',
  `fecha_aprobacion` datetime DEFAULT NULL,
  `es_reconexion` tinyint(1) DEFAULT 0,
  `monto_reconexion_usd` decimal(10,2) DEFAULT 2.00,
  `google_sheets_sync` tinyint(1) DEFAULT 0,
  `fecha_sync` datetime DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_recibo` (`numero_recibo`),
  KEY `tasa_cambio_id` (`tasa_cambio_id`),
  KEY `registrado_por` (`registrado_por`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_numero_recibo` (`numero_recibo`),
  KEY `idx_fecha_pago` (`fecha_pago`),
  KEY `idx_estado_comprobante` (`estado_comprobante`),
  KEY `idx_moneda_pago` (`moneda_pago`),
  KEY `idx_usuario_estado_compuesto` (`apartamento_usuario_id`,`estado_comprobante`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`tasa_cambio_id`) REFERENCES `tasa_cambio_bcv` (`id`),
  CONSTRAINT `pagos_ibfk_3` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `pagos_ibfk_4` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Registro completo de pagos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,1,'EST-000001',2.00,73.70,5,'bs_transferencia','2025-09-15 18:30:00','uploads/comprobantes/maria_sept_2025.jpg','aprobado',NULL,2,2,'2025-09-15 15:00:00',0,2.00,1,NULL,NULL),(2,5,'EST-000002',3.00,110.55,5,'usd_efectivo','2025-09-20 14:00:00',NULL,'no_aplica',NULL,2,NULL,NULL,0,2.00,1,NULL,NULL),(3,3,'EST-000003',4.00,148.80,6,'bs_transferencia','2025-10-25 20:45:00','uploads/comprobantes/laura_oct_2025.jpg','aprobado',NULL,2,1,'2025-10-25 17:00:00',0,2.00,1,NULL,NULL),(4,5,'EST-000004',3.00,111.60,6,'usd_efectivo','2025-10-22 15:30:00',NULL,'no_aplica',NULL,2,NULL,NULL,0,2.00,1,NULL,NULL);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `codigo` varchar(6) NOT NULL COMMENT 'C├│digo de 6 d├¡gitos',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_expiracion` timestamp NULL DEFAULT NULL COMMENT 'Expira en 15 minutos',
  `usado` tinyint(1) DEFAULT 0 COMMENT 'TRUE despu├®s de usar el c├│digo',
  `intentos_validacion` int(11) DEFAULT 0 COMMENT 'M├íximo 3 intentos',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_codigo` (`codigo`),
  KEY `idx_email` (`email`),
  KEY `idx_fecha_expiracion` (`fecha_expiracion`),
  KEY `idx_usado` (`usado`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tokens para recuperaci├│n de contrase├▒a';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_cambios`
--

DROP TABLE IF EXISTS `solicitudes_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes_cambios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apartamento_usuario_id` int(11) NOT NULL,
  `tipo_solicitud` enum('cambio_cantidad_controles','suspension_control','desactivacion_control') NOT NULL,
  `cantidad_controles_nueva` int(11) DEFAULT NULL COMMENT 'Solo para cambio_cantidad_controles',
  `control_id` int(11) DEFAULT NULL COMMENT 'Solo para suspension/desactivacion',
  `motivo` text NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada') DEFAULT 'pendiente',
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `aprobado_por` int(11) DEFAULT NULL,
  `fecha_respuesta` datetime DEFAULT NULL,
  `observaciones` text DEFAULT NULL COMMENT 'Comentarios del operador/admin',
  PRIMARY KEY (`id`),
  KEY `apartamento_usuario_id` (`apartamento_usuario_id`),
  KEY `control_id` (`control_id`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_estado` (`estado`),
  KEY `idx_tipo_solicitud` (`tipo_solicitud`),
  KEY `idx_fecha_solicitud` (`fecha_solicitud`),
  CONSTRAINT `solicitudes_cambios_ibfk_1` FOREIGN KEY (`apartamento_usuario_id`) REFERENCES `apartamento_usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `solicitudes_cambios_ibfk_2` FOREIGN KEY (`control_id`) REFERENCES `controles_estacionamiento` (`id`) ON DELETE SET NULL,
  CONSTRAINT `solicitudes_cambios_ibfk_3` FOREIGN KEY (`aprobado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Solicitudes de cambios en controles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_cambios`
--

LOCK TABLES `solicitudes_cambios` WRITE;
/*!40000 ALTER TABLE `solicitudes_cambios` DISABLE KEYS */;
INSERT INTO `solicitudes_cambios` VALUES (1,4,'cambio_cantidad_controles',3,NULL,'Necesito un control adicional para segundo veh├¡culo','pendiente','2025-11-03 14:00:00',NULL,NULL,NULL);
/*!40000 ALTER TABLE `solicitudes_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasa_cambio_bcv`
--

DROP TABLE IF EXISTS `tasa_cambio_bcv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasa_cambio_bcv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_usd_bs` decimal(10,4) NOT NULL COMMENT 'Tasa oficial BCV (Ej: 36.5000)',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `registrado_por` int(11) DEFAULT NULL COMMENT 'Usuario que actualiz├│ la tasa',
  `fuente` varchar(100) DEFAULT 'Manual' COMMENT 'Manual o API',
  PRIMARY KEY (`id`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_fecha_registro` (`fecha_registro`),
  CONSTRAINT `tasa_cambio_bcv_ibfk_1` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Historial de tasas BCV';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasa_cambio_bcv`
--

LOCK TABLES `tasa_cambio_bcv` WRITE;
/*!40000 ALTER TABLE `tasa_cambio_bcv` DISABLE KEYS */;
INSERT INTO `tasa_cambio_bcv` VALUES (1,36.5000,'2025-11-04 18:55:00',NULL,'Inicial'),(2,36.4500,'2025-01-01 14:00:00',1,'Manual'),(3,36.5200,'2025-01-15 14:00:00',1,'Manual'),(4,36.6000,'2025-02-01 14:00:00',1,'Manual'),(5,36.7500,'2025-03-01 14:00:00',1,'Manual'),(6,36.8500,'2025-10-01 14:00:00',1,'Manual'),(7,37.2000,'2025-11-01 14:00:00',1,'Manual'),(8,37.5000,'2025-11-04 13:00:00',1,'API'),(9,226.1305,'2025-11-05 14:00:00',1,'BCV Automático'),(10,226.1305,'2025-11-05 15:55:10',1,'BCV Automático'),(11,226.1305,'2025-11-05 15:59:27',1,'BCV Automático'),(12,226.1305,'2025-11-05 17:37:22',1,'BCV Automático'),(13,226.1305,'2025-11-05 17:42:55',1,'BCV Automático'),(14,226.1305,'2025-11-05 17:44:33',1,'BCV Automático'),(15,226.1305,'2025-11-05 17:57:46',1,'BCV Automático'),(16,226.1305,'2025-11-05 18:12:34',1,'BCV Automático');
/*!40000 ALTER TABLE `tasa_cambio_bcv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL COMMENT 'Hash BCRYPT',
  `telefono` varchar(20) DEFAULT NULL,
  `rol` enum('cliente','operador','consultor','administrador') NOT NULL DEFAULT 'cliente',
  `activo` tinyint(1) DEFAULT 1,
  `intentos_fallidos` int(11) DEFAULT 0 COMMENT 'M├íximo 5 intentos',
  `bloqueado_hasta` datetime DEFAULT NULL COMMENT 'Bloqueo temporal por intentos fallidos',
  `primer_acceso` tinyint(1) DEFAULT 1 COMMENT 'TRUE si es primera vez que ingresa',
  `password_temporal` tinyint(1) DEFAULT 1 COMMENT 'TRUE si password fue generado por admin',
  `perfil_completo` tinyint(1) DEFAULT 0 COMMENT 'TRUE cuando completa datos personales',
  `exonerado` tinyint(1) DEFAULT 0 COMMENT 'Usuarios exonerados no pagan mensualidad',
  `motivo_exoneracion` text DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_acceso` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_rol` (`rol`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Usuarios del sistema con 4 roles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador del Sistema','admin@estacionamiento.com','$2y$10$ffsFwzPc7EAfvxw2fFyFhuX0EwSnZZTEaGUA6xiB9S.7r8ep8b8z2','+58 424 1234567','administrador',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(2,'Operador Principal','operador@estacionamiento.com','$2y$10$jV5uMUjsvRmSapi1d67XCe54PZBQgt5Al.OiWPWSONwACl/xyaTjO','+58 414 2345678','operador',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(3,'Consultor del Sistema','consultor@estacionamiento.com','$2y$10$LQxl45/g.PIcNn1nA4pFZusMR2DkhbATXrfQ173Vt.d1vtDxlwlNO','+58 412 3456789','consultor',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(4,'María González','cliente1@email.com','$2y$10$6Sr1LN0WkQ11dJvXAbv0.uiwGflHQ5c0qnQZ7NhoQ4c.wL4OrL8Ja','+58 426 4567890','cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(5,'Roberto D├¡az','roberto.diaz@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 414 5678901','cliente',1,0,NULL,1,1,0,0,NULL,'2025-11-04 18:55:13',NULL),(6,'Laura Morales','laura.morales@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 424 6789012','cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(7,'Juan P├®rez','juan.perez@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 412 7890123','cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(8,'Ana Rodr├¡guez','ana.rodriguez@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 426 8901234','cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL),(9,'Carlos Mart├¡nez','carlos.martinez@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 414 9012345','cliente',1,0,NULL,0,0,1,1,NULL,'2025-11-04 18:55:13',NULL),(10,'Elena Silva','elena.silva@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','+58 424 0123456','cliente',1,0,NULL,0,0,1,0,NULL,'2025-11-04 18:55:13',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vista_controles_vacios`
--

DROP TABLE IF EXISTS `vista_controles_vacios`;
/*!50001 DROP VIEW IF EXISTS `vista_controles_vacios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vista_controles_vacios` AS SELECT
 1 AS `id`,
  1 AS `posicion_numero`,
  1 AS `receptor`,
  1 AS `numero_control_completo`,
  1 AS `estado` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vista_morosidad`
--

DROP TABLE IF EXISTS `vista_morosidad`;
/*!50001 DROP VIEW IF EXISTS `vista_morosidad`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vista_morosidad` AS SELECT
 1 AS `usuario_id`,
  1 AS `nombre_completo`,
  1 AS `email`,
  1 AS `telefono`,
  1 AS `apartamento`,
  1 AS `cantidad_controles`,
  1 AS `meses_pendientes`,
  1 AS `total_deuda_usd`,
  1 AS `total_deuda_bs`,
  1 AS `primer_mes_pendiente`,
  1 AS `ultimo_mes_pendiente`,
  1 AS `estado_morosidad` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_controles_vacios`
--

/*!50001 DROP VIEW IF EXISTS `vista_controles_vacios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_controles_vacios` AS select `c`.`id` AS `id`,`c`.`posicion_numero` AS `posicion_numero`,`c`.`receptor` AS `receptor`,`c`.`numero_control_completo` AS `numero_control_completo`,`c`.`estado` AS `estado` from `controles_estacionamiento` `c` where `c`.`estado` = 'vacio' and `c`.`apartamento_usuario_id` is null order by `c`.`posicion_numero`,`c`.`receptor` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_morosidad`
--

/*!50001 DROP VIEW IF EXISTS `vista_morosidad`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_morosidad` AS select `u`.`id` AS `usuario_id`,`u`.`nombre_completo` AS `nombre_completo`,`u`.`email` AS `email`,`u`.`telefono` AS `telefono`,concat(`a`.`bloque`,'-',`a`.`numero_apartamento`) AS `apartamento`,`au`.`cantidad_controles` AS `cantidad_controles`,count(`m`.`id`) AS `meses_pendientes`,sum(`m`.`monto_usd`) AS `total_deuda_usd`,sum(`m`.`monto_bs`) AS `total_deuda_bs`,min(`m`.`fecha_vencimiento`) AS `primer_mes_pendiente`,max(`m`.`fecha_vencimiento`) AS `ultimo_mes_pendiente`,case when count(`m`.`id`) >= 4 then 'Bloqueado' when count(`m`.`id`) >= 3 then 'Alerta' else 'Normal' end AS `estado_morosidad` from (((`usuarios` `u` join `apartamento_usuario` `au` on(`au`.`usuario_id` = `u`.`id` and `au`.`activo` = 1)) join `apartamentos` `a` on(`a`.`id` = `au`.`apartamento_id`)) join `mensualidades` `m` on(`m`.`apartamento_usuario_id` = `au`.`id` and `m`.`estado` in ('pendiente','vencido'))) where `u`.`rol` = 'cliente' and `u`.`activo` = 1 and `u`.`exonerado` = 0 group by `u`.`id`,`u`.`nombre_completo`,`u`.`email`,`u`.`telefono`,`a`.`bloque`,`a`.`numero_apartamento`,`au`.`cantidad_controles` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-05 14:12:58
